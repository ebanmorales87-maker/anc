import { useState, useEffect, useCallback } from 'react'

// ── Constants ────────────────────────────────────────────────────────────────
const USERS = {
  admin:   { password: 'admin123', role: 'admin', name: 'Administrador' },
  agente1: { password: 'agente123', role: 'agent', name: 'Agente' },
}

const fmtUSD = (v) =>
  '$' + parseFloat(v || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })

const calcTotals = (f = {}) => {
  const dmv      = parseFloat(f.dmv      || 0)
  const zelle    = parseFloat(f.zelle    || 0)
  const stripe   = parseFloat(f.stripe   || 0)
  const cash     = parseFloat(f.cash     || 0)
  const reembolso = parseFloat(f.reembolso || 0)
  const total    = dmv + zelle + stripe + cash
  return { total, reembolso, ganancia: total - reembolso }
}

const emptyForm = (clienteName = '', contactId = null) => ({
  _contactId: contactId,
  fecha: new Date().toISOString().split('T')[0],
  tramite: '', tramite_id: '', cliente: clienteName,
  dmv: '', zelle: '', stripe: '', cash: '', reembolso: '', comentario: '',
})

// ── API helpers (calls Next.js API routes) ───────────────────────────────────
async function apiFetch(path, opts = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    ...opts,
  })
  const data = await res.json()
  if (!res.ok) throw new Error(data?.message || data?.error || `HTTP ${res.status}`)
  return data
}

// ── Small components ─────────────────────────────────────────────────────────
function KpiCard({ icon, label, value, color }) {
  return (
    <div className="kpi">
      <div className="kpi-label"><i className={`ti ${icon}`} aria-hidden="true" /> {label}</div>
      <div className={`kpi-val ${color || ''}`}>{value}</div>
    </div>
  )
}

function StageBadge({ stage }) {
  const map = { 'New Lead': 'blue', 'Contacted': 'amber', 'Qualified': 'green',
                'Closed Won': 'green', 'Closed Lost': 'red' }
  return <span className={`badge badge-${map[stage] || 'gray'}`}>{stage || 'Sin etapa'}</span>
}

function Spinner() {
  return (
    <div className="loading">
      <div className="spinner" />
      Cargando datos de GoHighLevel...
    </div>
  )
}

function ErrorBanner({ msg, onRetry }) {
  return (
    <div className="error-banner">
      <i className="ti ti-alert-circle" aria-hidden="true" />
      <span>{msg}</span>
      {onRetry && (
        <button className="btn" onClick={onRetry}>
          <i className="ti ti-refresh" aria-hidden="true" /> Reintentar
        </button>
      )}
    </div>
  )
}

// ── Modal ────────────────────────────────────────────────────────────────────
function TramiteModal({ contacts, onSave, onClose, initialForm }) {
  const [form, setForm]     = useState(initialForm)
  const [saving, setSaving] = useState(false)
  const [err, setErr]       = useState('')

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))
  const t = calcTotals(form)

  const handleSave = async () => {
    if (!form.tramite.trim()) { setErr('El campo Trámite es requerido.'); return }
    if (!form.cliente.trim()) { setErr('El campo Cliente es requerido.'); return }
    setSaving(true); setErr('')
    try {
      await onSave(form)
      onClose()
    } catch (e) {
      setErr(e.message)
      setSaving(false)
    }
  }

  return (
    <div className="modal-bg" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-title">
          <span><i className="ti ti-file-dollar" aria-hidden="true" /> Registrar trámite DMV</span>
          <button className="btn icon-btn" onClick={onClose}><i className="ti ti-x" aria-hidden="true" /></button>
        </div>

        {err && <div className="form-err"><i className="ti ti-alert-circle" aria-hidden="true" /> {err}</div>}

        <div className="form-grid">
          <div className="form-field">
            <label>Fecha</label>
            <input type="date" value={form.fecha} onChange={e => set('fecha', e.target.value)} />
          </div>
          <div className="form-field">
            <label>ID Trámite</label>
            <input placeholder="ej. DMV-2024-001" value={form.tramite_id} onChange={e => set('tramite_id', e.target.value)} />
          </div>
          <div className="form-field full">
            <label>Trámite <span className="req">*</span></label>
            <input placeholder="Tipo de trámite" value={form.tramite} onChange={e => set('tramite', e.target.value)} />
          </div>
          <div className="form-field full">
            <label>Cliente <span className="req">*</span></label>
            <input
              placeholder="Nombre del cliente"
              value={form.cliente}
              onChange={e => set('cliente', e.target.value)}
              list="clients-list"
            />
            <datalist id="clients-list">
              {contacts.map(c => {
                const name = `${c.firstName || ''} ${c.lastName || ''}`.trim()
                return <option key={c.id} value={name} />
              })}
            </datalist>
          </div>
          <div className="form-field">
            <label>DMV ($)</label>
            <input type="number" min="0" step="0.01" placeholder="0.00" value={form.dmv} onChange={e => set('dmv', e.target.value)} />
          </div>
          <div className="form-field">
            <label>Zelle ($)</label>
            <input type="number" min="0" step="0.01" placeholder="0.00" value={form.zelle} onChange={e => set('zelle', e.target.value)} />
          </div>
          <div className="form-field">
            <label>Stripe ($)</label>
            <input type="number" min="0" step="0.01" placeholder="0.00" value={form.stripe} onChange={e => set('stripe', e.target.value)} />
          </div>
          <div className="form-field">
            <label>Cash ($)</label>
            <input type="number" min="0" step="0.01" placeholder="0.00" value={form.cash} onChange={e => set('cash', e.target.value)} />
          </div>
          <div className="form-field full">
            <label>Reembolso ($)</label>
            <input type="number" min="0" step="0.01" placeholder="0.00" value={form.reembolso} onChange={e => set('reembolso', e.target.value)} />
          </div>
        </div>

        <div className="calc-row">
          <div className="calc-item">
            <div className="calc-lbl">Total comisión</div>
            <div className="calc-val green">{fmtUSD(t.total)}</div>
          </div>
          <div className="calc-divider" />
          <div className="calc-item">
            <div className="calc-lbl">Reembolso</div>
            <div className="calc-val red">{fmtUSD(t.reembolso)}</div>
          </div>
          <div className="calc-divider" />
          <div className="calc-item">
            <div className="calc-lbl">Ganancia neta</div>
            <div className={`calc-val ${t.ganancia >= 0 ? 'green' : 'red'}`}>{fmtUSD(t.ganancia)}</div>
          </div>
        </div>

        <div className="form-field full" style={{ marginTop: 10 }}>
          <label>Comentario</label>
          <textarea rows={3} placeholder="Notas adicionales..." value={form.comentario} onChange={e => set('comentario', e.target.value)} />
        </div>

        <div className="modal-footer">
          <button className="btn" onClick={onClose}>Cancelar</button>
          <button className="btn primary" onClick={handleSave} disabled={saving}>
            <i className="ti ti-device-floppy" aria-hidden="true" />
            {saving ? 'Guardando...' : 'Guardar en GHL'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ── Login ────────────────────────────────────────────────────────────────────
function Login({ onLogin }) {
  const [user, setUser] = useState('')
  const [pass, setPass] = useState('')
  const [err, setErr]   = useState('')

  const handle = () => {
    if (USERS[user] && USERS[user].password === pass) {
      onLogin({ username: user, ...USERS[user] })
    } else {
      setErr('Usuario o contraseña incorrectos.')
    }
  }

  return (
    <div className="login-wrap">
      <div className="login-card">
        <div className="login-logo">
          <i className="ti ti-shield-check" aria-hidden="true" />
          <span>DMV Accounts</span>
        </div>
        <div className="login-hint">
          <i className="ti ti-info-circle" aria-hidden="true" />
          <span>Admin: <code>admin / admin123</code> &nbsp;·&nbsp; Agente: <code>agente1 / agente123</code></span>
        </div>
        <div className="form-field" style={{ marginBottom: 10 }}>
          <label>Usuario</label>
          <input value={user} onChange={e => setUser(e.target.value)} placeholder="admin" onKeyDown={e => e.key === 'Enter' && handle()} />
        </div>
        <div className="form-field" style={{ marginBottom: 10 }}>
          <label>Contraseña</label>
          <input type="password" value={pass} onChange={e => setPass(e.target.value)} placeholder="••••••••" onKeyDown={e => e.key === 'Enter' && handle()} />
        </div>
        {err && <div className="form-err" style={{ marginBottom: 8 }}>{err}</div>}
        <button className="btn primary full-w" onClick={handle} style={{ marginTop: 8 }}>
          <i className="ti ti-login" aria-hidden="true" /> Iniciar sesión
        </button>
      </div>
    </div>
  )
}

// ── Dashboard ────────────────────────────────────────────────────────────────
function Dashboard({ contacts, dmvRecords }) {
  const allT           = dmvRecords.map(r => calcTotals(r.fields || r))
  const totalGanancia  = allT.reduce((s, t) => s + t.ganancia,  0)
  const totalReembolso = allT.reduce((s, t) => s + t.reembolso, 0)
  const now = new Date()
  const tramitesMes = dmvRecords.filter(r => {
    const f = r.fields || r
    if (!f.fecha) return false
    const d = new Date(f.fecha)
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear()
  }).length

  return (
    <div>
      <div className="kpi-grid">
        <KpiCard icon="ti-users"          label="Contactos activos"  value={contacts.length}        color="blue"  />
        <KpiCard icon="ti-trending-up"    label="Ganancia total"     value={fmtUSD(totalGanancia)}  color="green" />
        <KpiCard icon="ti-arrow-back-up"  label="Total reembolsos"   value={fmtUSD(totalReembolso)} color="red"   />
        <KpiCard icon="ti-calendar-month" label="Trámites este mes"  value={tramitesMes} />
      </div>
      <div className="section-header"><span className="section-title">Trámites recientes</span></div>
      <div className="table-wrap">
        <table>
          <thead>
            <tr><th>Trámite</th><th>Cliente</th><th>Comisión</th><th>Reembolso</th><th>Ganancia</th><th>Fecha</th></tr>
          </thead>
          <tbody>
            {dmvRecords.slice(0, 10).map((r, i) => {
              const f = r.fields || r
              const t = calcTotals(f)
              return (
                <tr key={r.id || i}>
                  <td>{f.tramite || '—'}</td>
                  <td>{f.cliente || '—'}</td>
                  <td className="amt-green">{fmtUSD(t.total)}</td>
                  <td className="amt-red">{fmtUSD(t.reembolso)}</td>
                  <td className={t.ganancia >= 0 ? 'amt-green' : 'amt-red'}>{fmtUSD(t.ganancia)}</td>
                  <td>{f.fecha ? f.fecha.substring(0, 10) : '—'}</td>
                </tr>
              )
            })}
            {dmvRecords.length === 0 && <tr><td colSpan={6} className="empty">Sin trámites registrados</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ── Contacts ─────────────────────────────────────────────────────────────────
function ContactsList({ contacts, dmvRecords, onSelect }) {
  const [q, setQ] = useState('')
  const filtered = contacts.filter(c => {
    const name = `${c.firstName || ''} ${c.lastName || ''}`.toLowerCase()
    return name.includes(q.toLowerCase()) || (c.email || '').toLowerCase().includes(q.toLowerCase())
  })

  const getStats = (c) => {
    const name = `${c.firstName || ''} ${c.lastName || ''}`.trim()
    const recs = dmvRecords.filter(r => (r.fields || r).cliente === name)
    return {
      count:    recs.length,
      ganancia: recs.reduce((s, r) => s + calcTotals(r.fields || r).ganancia, 0),
    }
  }

  return (
    <div>
      <div className="section-header">
        <span className="section-title">Contactos del pipeline ({contacts.length})</span>
        <input className="search-input" placeholder="Buscar nombre o email..." value={q} onChange={e => setQ(e.target.value)} />
      </div>
      <div className="table-wrap">
        <table>
          <thead>
            <tr><th>Nombre</th><th>Email</th><th>Teléfono</th><th>Etapa</th><th>Trámites</th><th>Ganancia</th><th></th></tr>
          </thead>
          <tbody>
            {filtered.map(c => {
              const name = `${c.firstName || ''} ${c.lastName || ''}`.trim() || 'Sin nombre'
              const s = getStats(c)
              return (
                <tr key={c.id} onClick={() => onSelect(c)} style={{ cursor: 'pointer' }}>
                  <td><strong>{name}</strong></td>
                  <td>{c.email || '—'}</td>
                  <td>{c.phone || '—'}</td>
                  <td><StageBadge stage={c.pipelineStage || c.stage} /></td>
                  <td style={{ textAlign: 'center' }}>{s.count}</td>
                  <td className={s.ganancia >= 0 ? 'amt-green' : 'amt-red'}>{fmtUSD(s.ganancia)}</td>
                  <td>
                    <button className="btn icon-btn" onClick={e => { e.stopPropagation(); onSelect(c) }}>
                      <i className="ti ti-eye" aria-hidden="true" />
                    </button>
                  </td>
                </tr>
              )
            })}
            {filtered.length === 0 && <tr><td colSpan={7} className="empty">Sin resultados</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ── Contact detail ────────────────────────────────────────────────────────────
function ContactDetail({ contact, dmvRecords, onBack, onAddRecord }) {
  const name     = `${contact.firstName || ''} ${contact.lastName || ''}`.trim() || 'Sin nombre'
  const initials = ((contact.firstName?.[0] || '') + (contact.lastName?.[0] || '')).toUpperCase() || name[0]?.toUpperCase() || '?'
  const recs     = dmvRecords.filter(r => (r.fields || r).cliente === name)
  const totals   = recs.map(r => calcTotals(r.fields || r))
  const sumComision  = totals.reduce((s, t) => s + t.total,     0)
  const sumReembolso = totals.reduce((s, t) => s + t.reembolso, 0)
  const sumGanancia  = totals.reduce((s, t) => s + t.ganancia,  0)

  return (
    <div>
      <button className="back-btn" onClick={onBack}>
        <i className="ti ti-arrow-left" aria-hidden="true" /> Volver a contactos
      </button>

      <div className="panel">
        <div className="contact-header">
          <div className="avatar">{initials}</div>
          <div>
            <div className="contact-name">{name}</div>
            <div className="contact-email">{contact.email || 'Sin email'}</div>
          </div>
          <div style={{ marginLeft: 'auto' }}>
            <StageBadge stage={contact.pipelineStage || contact.stage} />
          </div>
        </div>
        <div className="detail-grid">
          <div><span className="detail-lbl">Teléfono</span><span className="detail-val">{contact.phone || '—'}</span></div>
          <div><span className="detail-lbl">ID de contacto</span><span className="detail-val mono">{contact.id}</span></div>
        </div>
      </div>

      <div className="kpi-grid three">
        <KpiCard icon="ti-receipt"       label="Comisión total"    value={fmtUSD(sumComision)}  color="blue"  />
        <KpiCard icon="ti-arrow-back-up" label="Total reembolsos"  value={fmtUSD(sumReembolso)} color="red"   />
        <KpiCard icon="ti-trending-up"   label="Ganancia neta"     value={fmtUSD(sumGanancia)}  color="green" />
      </div>

      <div className="section-header">
        <span className="section-title">Trámites DMV ({recs.length})</span>
        <button className="btn primary" onClick={() => onAddRecord(contact.id, name)}>
          <i className="ti ti-plus" aria-hidden="true" /> Nuevo trámite
        </button>
      </div>

      <div className="table-wrap">
        <table>
          <thead>
            <tr><th>Fecha</th><th>Trámite</th><th>DMV</th><th>Zelle</th><th>Stripe</th><th>Cash</th><th>Comisión</th><th>Reembolso</th><th>Ganancia</th><th>ID Trámite</th></tr>
          </thead>
          <tbody>
            {recs.map((r, i) => {
              const f = r.fields || r
              const t = calcTotals(f)
              return (
                <tr key={r.id || i}>
                  <td>{f.fecha ? f.fecha.substring(0, 10) : '—'}</td>
                  <td>{f.tramite || '—'}</td>
                  <td>{fmtUSD(f.dmv)}</td>
                  <td>{fmtUSD(f.zelle)}</td>
                  <td>{fmtUSD(f.stripe)}</td>
                  <td>{fmtUSD(f.cash)}</td>
                  <td className="amt-green">{fmtUSD(t.total)}</td>
                  <td className="amt-red">{fmtUSD(t.reembolso)}</td>
                  <td className={t.ganancia >= 0 ? 'amt-green' : 'amt-red'}>{fmtUSD(t.ganancia)}</td>
                  <td className="mono">{f.tramite_id || '—'}</td>
                </tr>
              )
            })}
            {recs.length > 0 && (
              <tr className="totals-row">
                <td colSpan={6}>Totales</td>
                <td className="amt-green">{fmtUSD(sumComision)}</td>
                <td className="amt-red">{fmtUSD(sumReembolso)}</td>
                <td className={sumGanancia >= 0 ? 'amt-green' : 'amt-red'}>{fmtUSD(sumGanancia)}</td>
                <td></td>
              </tr>
            )}
            {recs.length === 0 && (
              <tr>
                <td colSpan={10} className="empty">
                  Sin trámites. <span className="link" onClick={() => onAddRecord(contact.id, name)}>Agregar primero</span>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ── All records ───────────────────────────────────────────────────────────────
function RecordsView({ dmvRecords, onAddRecord }) {
  const allT         = dmvRecords.map(r => calcTotals(r.fields || r))
  const sumComision  = allT.reduce((s, t) => s + t.total,     0)
  const sumReembolso = allT.reduce((s, t) => s + t.reembolso, 0)
  const sumGanancia  = allT.reduce((s, t) => s + t.ganancia,  0)

  return (
    <div>
      <div className="section-header">
        <span className="section-title">Todos los trámites DMV ({dmvRecords.length})</span>
        <button className="btn primary" onClick={() => onAddRecord(null, '')}>
          <i className="ti ti-plus" aria-hidden="true" /> Nuevo trámite
        </button>
      </div>
      <div className="table-wrap">
        <table>
          <thead>
            <tr><th>Fecha</th><th>Cliente</th><th>Trámite</th><th>Comisión</th><th>Reembolso</th><th>Ganancia</th><th>Comentario</th></tr>
          </thead>
          <tbody>
            {dmvRecords.map((r, i) => {
              const f = r.fields || r
              const t = calcTotals(f)
              return (
                <tr key={r.id || i}>
                  <td>{f.fecha ? f.fecha.substring(0, 10) : '—'}</td>
                  <td>{f.cliente || '—'}</td>
                  <td>{f.tramite || '—'}</td>
                  <td className="amt-green">{fmtUSD(t.total)}</td>
                  <td className="amt-red">{fmtUSD(t.reembolso)}</td>
                  <td className={t.ganancia >= 0 ? 'amt-green' : 'amt-red'}>{fmtUSD(t.ganancia)}</td>
                  <td className="muted">{(f.comentario || '').substring(0, 40) || '—'}</td>
                </tr>
              )
            })}
            {dmvRecords.length > 0 && (
              <tr className="totals-row">
                <td colSpan={3}>Totales</td>
                <td className="amt-green">{fmtUSD(sumComision)}</td>
                <td className="amt-red">{fmtUSD(sumReembolso)}</td>
                <td className={sumGanancia >= 0 ? 'amt-green' : 'amt-red'}>{fmtUSD(sumGanancia)}</td>
                <td></td>
              </tr>
            )}
            {dmvRecords.length === 0 && <tr><td colSpan={7} className="empty">Sin trámites registrados</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ── Root ──────────────────────────────────────────────────────────────────────
export default function Home() {
  const [auth, setAuth]           = useState(null)
  const [view, setView]           = useState('dashboard')
  const [contacts, setContacts]   = useState([])
  const [dmvRecords, setDmv]      = useState([])
  const [selectedContact, setSel] = useState(null)
  const [loading, setLoading]     = useState(false)
  const [error, setError]         = useState(null)
  const [modal, setModal]         = useState(null)

  const loadData = useCallback(async () => {
    setLoading(true); setError(null)
    try {
      const [cData, dData] = await Promise.all([
        apiFetch('/api/contacts'),
        apiFetch('/api/dmv-records'),
      ])
      const raw = cData.contacts?.contacts || cData.contacts || []
      setContacts(Array.isArray(raw) ? raw : [])
      setDmv(dData.records || dData.data || [])
    } catch (e) {
      setError(e.message)
    }
    setLoading(false)
  }, [])

  useEffect(() => { if (auth) loadData() }, [auth, loadData])

  const handleSaveRecord = async (form) => {
    const dmv      = parseFloat(form.dmv      || 0)
    const zelle    = parseFloat(form.zelle    || 0)
    const stripe   = parseFloat(form.stripe   || 0)
    const cash     = parseFloat(form.cash     || 0)
    const reembolso = parseFloat(form.reembolso || 0)
    const total_comision = dmv + zelle + stripe + cash
    const ganancia = total_comision - reembolso

    await apiFetch('/api/dmv-records', {
      method: 'POST',
      body: JSON.stringify({
        fields: {
          fecha: form.fecha, comentario: form.comentario, cliente: form.cliente,
          reembolso, tramite: form.tramite, total_comision, ganancia,
          dmv, zelle, stripe, cash, tramite_id: form.tramite_id,
        },
      }),
    })
    await loadData()
  }

  if (!auth) return <Login onLogin={setAuth} />

  const isAdmin = auth.role === 'admin'

  return (
    <div className="app-layout">
      <header className="topbar">
        <div className="logo"><i className="ti ti-shield-check" aria-hidden="true" /> DMV Accounts</div>
        <div className="user-info">
          <span>{auth.name}</span>
          <span className={`role-pill ${isAdmin ? 'admin' : 'agent'}`}>{isAdmin ? 'Administrador' : 'Agente'}</span>
          <button className="btn icon-btn" onClick={() => { setAuth(null); setContacts([]); setDmv([]) }}>
            <i className="ti ti-logout" aria-hidden="true" />
          </button>
        </div>
      </header>

      <div className="app-body">
        <nav className="sidebar">
          {isAdmin && (
            <div className={`nav-item ${view === 'dashboard' ? 'active' : ''}`} onClick={() => setView('dashboard')}>
              <i className="ti ti-layout-dashboard" aria-hidden="true" /> Dashboard
            </div>
          )}
          <div className={`nav-item ${view === 'contacts' || view === 'detail' ? 'active' : ''}`} onClick={() => setView('contacts')}>
            <i className="ti ti-users" aria-hidden="true" /> Contactos
          </div>
          <div className={`nav-item ${view === 'records' ? 'active' : ''}`} onClick={() => setView('records')}>
            <i className="ti ti-file-dollar" aria-hidden="true" /> Trámites DMV
          </div>
          <div className="nav-item" onClick={loadData}>
            <i className="ti ti-refresh" aria-hidden="true" /> Actualizar
          </div>
        </nav>

        <main className="main-content">
          {loading && <Spinner />}
          {!loading && error && <ErrorBanner msg={error} onRetry={loadData} />}
          {!loading && !error && (
            <>
              {view === 'dashboard' && isAdmin && <Dashboard contacts={contacts} dmvRecords={dmvRecords} />}
              {(view === 'contacts') && (
                <ContactsList contacts={contacts} dmvRecords={dmvRecords} onSelect={c => { setSel(c); setView('detail') }} />
              )}
              {view === 'detail' && selectedContact && (
                <ContactDetail
                  contact={selectedContact}
                  dmvRecords={dmvRecords}
                  onBack={() => setView('contacts')}
                  onAddRecord={(id, name) => setModal({ contactId: id, clienteName: name })}
                  isAdmin={isAdmin}
                />
              )}
              {view === 'records' && (
                <RecordsView dmvRecords={dmvRecords} onAddRecord={(id, name) => setModal({ contactId: id, clienteName: name })} />
              )}
            </>
          )}
        </main>
      </div>

      {modal && (
        <TramiteModal
          contacts={contacts}
          initialForm={emptyForm(modal.clienteName, modal.contactId)}
          onSave={handleSaveRecord}
          onClose={() => setModal(null)}
        />
      )}
    </div>
  )
}
