const GHL_API_KEY     = process.env.GHL_API_KEY
const GHL_LOCATION_ID = process.env.GHL_LOCATION_ID
const BASE            = 'https://services.leadconnectorhq.com'

const ghlHeaders = {
  Authorization: `Bearer ${GHL_API_KEY}`,
  'Content-Type': 'application/json',
  Version: '2021-07-28',
}

export default async function handler(req, res) {
  const { id } = req.query

  // GET all records
  if (req.method === 'GET' && !id) {
    try {
      const r = await fetch(
        `${BASE}/objects/dmv_accounts/records?locationId=${GHL_LOCATION_ID}&limit=100`,
        { headers: ghlHeaders }
      )
      const data = await r.json()
      if (!r.ok) return res.status(r.status).json(data)
      return res.status(200).json(data)
    } catch (e) {
      return res.status(500).json({ error: e.message })
    }
  }

  // POST create record
  if (req.method === 'POST') {
    try {
      const r = await fetch(`${BASE}/objects/dmv_accounts/records`, {
        method: 'POST',
        headers: ghlHeaders,
        body: JSON.stringify({ locationId: GHL_LOCATION_ID, ...req.body }),
      })
      const data = await r.json()
      if (!r.ok) return res.status(r.status).json(data)
      return res.status(200).json(data)
    } catch (e) {
      return res.status(500).json({ error: e.message })
    }
  }

  // PUT update record
  if (req.method === 'PUT' && id) {
    try {
      const r = await fetch(`${BASE}/objects/dmv_accounts/records/${id}`, {
        method: 'PUT',
        headers: ghlHeaders,
        body: JSON.stringify(req.body),
      })
      const data = await r.json()
      if (!r.ok) return res.status(r.status).json(data)
      return res.status(200).json(data)
    } catch (e) {
      return res.status(500).json({ error: e.message })
    }
  }

  // DELETE record
  if (req.method === 'DELETE' && id) {
    try {
      const r = await fetch(`${BASE}/objects/dmv_accounts/records/${id}`, {
        method: 'DELETE',
        headers: ghlHeaders,
      })
      if (!r.ok) return res.status(r.status).json({ error: 'Delete failed' })
      return res.status(200).json({ success: true })
    } catch (e) {
      return res.status(500).json({ error: e.message })
    }
  }

  res.status(405).end()
}
