const GHL_API_KEY     = process.env.GHL_API_KEY
const GHL_LOCATION_ID = process.env.GHL_LOCATION_ID
const BASE            = 'https://services.leadconnectorhq.com'

const headers = {
  Authorization: `Bearer ${GHL_API_KEY}`,
  'Content-Type': 'application/json',
  Version: '2021-07-28',
}

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).end()
  try {
    const r = await fetch(
      `${BASE}/contacts/search?locationId=${GHL_LOCATION_ID}&limit=100`,
      { headers }
    )
    const data = await r.json()
    if (!r.ok) return res.status(r.status).json(data)
    res.status(200).json(data)
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
}
